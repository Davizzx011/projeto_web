# ⛰️ Projeto Final

Vamos a mais uma conquista na sua formação profissional !

---

## Integrantes
** Quem é essa equipe massa !

Davi, Guihlerme

Preciso que faça uma auto biografia sobre ti, pensando com uma empresa pode contratar você.
* **Lembre** do seu Portifolio e como suas hard e soft skill's pode ajudar e Lembre-se do Hikigai!

---

## Tema do Projeto
** Como em 3 minutos podemos entender seu Projeto !

Pense como foi criar com seus colegas de sala para ser algo divertido e facil de fazer, sem muita pressão ou cobrança
* **Precisa** ser algo simples de ler e sem muitas perguntas, Combinado!

---

## Divisão de tarefas
** Quem ira ser responsavel por partes do projeto?

Não será escrito na pedra! Mas precisamos saber quem cuidou de cada parte e o "Segurar a cartolina" Não é parte das tarefas
e sim todos devem pensar em como apresentar a continuação do outro.

* **Veja** que o Projeto não reponsabilidade de um mas sim de todos, um cuidando do outro!

**Pronto para conquistar seu merito ? #BoraCodar** ✨
